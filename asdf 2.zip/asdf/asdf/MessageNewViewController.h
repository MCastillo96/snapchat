//
//  MessageNewViewController.h
//  QuickSnap
//
//  Created by Marc Castillo on 10/31/16.
//  Copyright © 2016 Ethan Soucy. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AFNetworking.h"
#import "MessageListViewController.h"
@interface MessageNewViewController : UIViewController <UIImagePickerControllerDelegate, UINavigationControllerDelegate>

@property int source;
@property (weak, nonatomic) IBOutlet UIImageView *imageview;
@property (weak, nonatomic) IBOutlet UITextField *recipientEmail;

@property (weak, nonatomic) IBOutlet UITextField *optionalMessage;
- (IBAction)didClickSendMessage:(id)sender;

@end
