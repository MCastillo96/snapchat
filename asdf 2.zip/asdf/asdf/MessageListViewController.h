
#import <UIKit/UIKit.h>
#import "AFNetworking.h"

@interface MessageListViewController : UIViewController <UITableViewDelegate, UITableViewDataSource>
{
    NSMutableArray *arrSnaps;
    AFHTTPSessionManager *manager;
    NSString *token;
  NSString *snapID;
}
@property (weak, nonatomic) IBOutlet UITableView *tblSnaps;
@property int source;
//@property int snapID;


@end

