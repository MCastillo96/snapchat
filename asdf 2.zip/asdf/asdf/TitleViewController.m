

#import "TitleViewController.h"

@interface TitleViewController ()

@end

@implementation TitleViewController


-(IBAction) didClickLogin: (id) sender {
    [self performSegueWithIdentifier:@"segueTitleToLogin" sender:self];
}
-(IBAction) didClickSignup: (id) sender {
    [self performSegueWithIdentifier:@"segueTitleToSignup" sender:self];
    
}

@end
