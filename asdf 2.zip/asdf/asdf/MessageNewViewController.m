//
//  MessageNewViewController.m
//  QuickSnap
//
//  Created by Marc Castillo on 10/31/16.
//  Copyright © 2016 Ethan Soucy. All rights reserved.
//

#import "MessageNewViewController.h"

@interface MessageNewViewController ()

@end

@implementation MessageNewViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    //[self viewDidAppear:true];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) viewDidAppear: (BOOL)animated {
    [super viewDidAppear:animated];
    
    if ((self.source == -1) && self.imageview.image == nil) {
        [self.navigationController popViewControllerAnimated:YES];
        
        //[self segues];

    }else if (self.imageview.image == nil) {
        UIImagePickerController *picker = [[UIImagePickerController alloc] init];
        picker.delegate = self;
        picker.allowsEditing = YES;
        picker.sourceType = self.source;
        [self presentViewController:picker animated:YES completion:NULL];
        self.source = -1;
              

    }
   // [self segues];

}

- (void) imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    NSLog(@"Finished picking");
    UIImage *chosenImage = info[UIImagePickerControllerEditedImage];
    self.imageview.image = chosenImage;
   [picker dismissViewControllerAnimated:YES completion:NULL];
    //[self segues];

   // UIStoryboard* sb = [UIStoryboard storyboardWithName:@"Main.storyboard" bundle:nil];
    //UIViewController* myVC = [sb instantiateViewControllerWithIdentifier:@"MessageNewViewController"];
    //[self presentViewController:myVC animated:YES completion:nil];
}






/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)didClickSendMessage:(id)sender {
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSString *token = [defaults objectForKey:@"token"];
    
    NSDictionary *parameters = @{@"token": token,@"email":self.recipientEmail.text, @"message":self.optionalMessage.text};
    AFHTTPSessionManager * manager = [[AFHTTPSessionManager alloc] initWithSessionConfiguration:
                                      [NSURLSessionConfiguration defaultSessionConfiguration]];
    [manager setRequestSerializer:[AFHTTPRequestSerializer serializer]];
    [manager setResponseSerializer:[AFJSONResponseSerializer serializer]];
    
    
    NSData *data = UIImageJPEGRepresentation(self.imageview.image, 1.0);
    [manager POST:@"http://www.tageninformatics.com/client/jwu/csis3070_assignment3/snap/create/" parameters: parameters constructingBodyWithBlock:^(id<AFMultipartFormData> _Nonnull formData) {
        [formData appendPartWithFileData:data name:@"image" fileName:@"image.jpg" mimeType:@"image/jpeg"];
        
    } progress:nil
          success:^(NSURLSessionDataTask * _Nonnull task, id _Nullable responseObject) {
              NSLog(@"Success!");
              NSLog(@"Server Response: %@", responseObject);
              
              [self successInLoading];
            //  [self.tblSnaps reloadData];

              
          } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
              NSLog(@"Network Error: %@" , error);
              [self errorInLoading];
          }];
    
    
        [self performSegueWithIdentifier:@"SegueMessageListViewController" sender: self];
}



-(void)errorInLoading{
    UIAlertController* alert = [UIAlertController alertControllerWithTitle:@"Error"
                                                                   message:@"Something went wrong"
                                                            preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction* defaultAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault
                                                          handler:^(UIAlertAction * action) {}];
    
    [alert addAction:defaultAction];
    [self presentViewController:alert animated:YES completion:nil];
}






-(void)successInLoading{
    UIAlertController* alert = [UIAlertController alertControllerWithTitle:@"Success"
                                                                   message:@"You have succesfully sent a snap"
                                                            preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction* defaultAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault
                                                          handler:^(UIAlertAction * action) {}];
    
    [alert addAction:defaultAction];
    [self presentViewController:alert animated:YES completion:nil];
}

@end
