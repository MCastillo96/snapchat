

#import "LoginViewController.h"


@implementation LoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.btnLogin.enabled = NO;
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]
                                   initWithTarget:self
                                   action:@selector(dismissKeyboard)];
    [self.view addGestureRecognizer:tap];
    
    
}
- (IBAction)didClickLogin:(id)sender {

    NSDictionary *parameters = @{@"email": self.txtEmail.text, @"password":self.txtPassword.text};
    
    AFHTTPSessionManager *manager = [[AFHTTPSessionManager alloc]initWithSessionConfiguration:[NSURLSessionConfiguration defaultSessionConfiguration]];
    
    [manager setRequestSerializer:[AFHTTPRequestSerializer serializer]];
    [manager setResponseSerializer:[AFJSONResponseSerializer serializer]];
    
    [manager POST:@"http://www.tageninformatics.com/client/jwu/csis3070_assignment3/user/login/" parameters:parameters progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {

        NSDictionary * response = responseObject;
        if ([[response objectForKey:@"result"] isEqualToString:@"success"]) {
            NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
            [defaults setObject:[response objectForKey:@"token"] forKey:@"token"];
            [self performSegueWithIdentifier:@"segueLoginToList" sender:self];
            
            NSLog(@"success!");
        } else {
            UIAlertController * alert = [UIAlertController
                                         alertControllerWithTitle:@"Error"
                                         message:[response objectForKey:@"message"]
                                         preferredStyle:UIAlertControllerStyleAlert];
            
            UIAlertAction* okButton = [UIAlertAction
                                       actionWithTitle:@"OK"
                                       style:UIAlertActionStyleDefault
                                       handler:nil];
            
            [alert addAction:okButton];
            
            [self presentViewController:alert animated:YES completion:nil];
            
            

        }
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSLog(@"error: %@", error);
    }];
    
    
 }


-(void)dismissKeyboard {
    [self.txtEmail resignFirstResponder];
    [self.txtPassword resignFirstResponder];
    
}


-(IBAction)textFieldDidChange :(UITextField *) textField{
    if(![self.txtEmail.text isEqualToString:@""] && ![self.txtPassword.text isEqualToString:@""])
    {
        self.btnLogin.enabled = YES;
    }
    else{
        self.btnLogin.enabled = NO;
    }
}

@end
