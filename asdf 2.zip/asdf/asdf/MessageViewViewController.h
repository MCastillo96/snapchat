//
//  MessageViewViewController.h
//  QuickSnap
//
//  Created by Marc Castillo on 11/6/16.
//  Copyright © 2016 Ethan Soucy. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AFNetworking.h"
@interface MessageViewViewController : UIViewController{
   
    AFHTTPSessionManager *manager;

    NSString *snapID;
 
}
@property (weak, nonatomic) IBOutlet UIImageView *imageViews;
@property (weak, nonatomic) IBOutlet UILabel *firstName;
//@property int snapID;
@property (weak, nonatomic) IBOutlet UILabel *lastName;
@property (weak, nonatomic) IBOutlet UILabel *messageSnap;
@property (weak, nonatomic) IBOutlet UILabel *timinglbl;
@property int timeSec;
@property NSTimer *timer;

@end
