//
//  main.m
//  asdf
//
//  Created by Marc Castillo on 11/9/16.
//  Copyright © 2016 MarcLens. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
