//
//  MessageViewViewController.m
//  QuickSnap
//
//  Created by Marc Castillo on 11/6/16.
//  Copyright © 2016 Ethan Soucy. All rights reserved.
//

#import "MessageViewViewController.h"

@interface MessageViewViewController ()

@end

@implementation MessageViewViewController

- (void)viewDidLoad {
    [super viewDidLoad];
   // NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
   // _snapID = [NSUserDefaults integerForKey:"snapID"];









    [self viewWillAppear:true];


  //  [self viewWillAppear:true];
    
    
    
}




/*
-(void) viewDidAppear: (BOOL)animated {
    [super viewDidAppear:animated];
 
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSString *token = [defaults objectForKey:@"token"];
    
    NSDictionary *parameters = @{@"email":self.recipientEmail.text, @"message":self.optionalMessage.text};
    AFHTTPSessionManager * manager = [[AFHTTPSessionManager alloc] initWithSessionConfiguration:
                                      [NSURLSessionConfiguration defaultSessionConfiguration]];
    [manager setRequestSerializer:[AFHTTPRequestSerializer serializer]];
    [manager setResponseSerializer:[AFJSONResponseSerializer serializer]];
    
    
    NSData *data = UIImageJPEGRepresentation(self.imageview.image, 1.0);
    [manager GET:@"http://www.tageninformatics.com/client/jwu/csis3070_assignment3/snap/create/" parameters: parameters constructingBodyWithBlock:^(id<AFMultipartFormData> _Nonnull formData) {
        [formData appendPartWithFileData:data name:@"image" fileName:@"image.jpg" mimeType:@"image/jpeg"];
        
    } progress:nil
          success:^(NSURLSessionDataTask * _Nonnull task, id _Nullable responseObject) {
              NSLog(@"Success!");
              NSLog(@"Server Response: %@", responseObject);
              [self successInLoading];
              
          } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
              NSLog(@"Network Error: %@" , error);
              [self errorInLoading];
          }];
    
    
    [self performSegueWithIdentifier:@"SegueMessageListViewController" sender: self];
       // [self segues];
 
}
*/
-(void) viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];

    // NSString *snap_id = [[arrSnaps objectAtIndex:[indexPath row]] objectForKey:@"id"];
    //network call to delete
    // NSInteger tempInt = [[NSUserDefaults standardUserDefaults] integerForKey:@"snapID"];
    //NSLog(@"OOOOOOOO     %ld    0000000", (long)tempInt);
    snapID = [[NSUserDefaults standardUserDefaults] objectForKey:@"id"];
    NSLog(@"OOOOOOOO     %@    0000000", snapID);
 NSString *token;
    token = [[NSUserDefaults standardUserDefaults] objectForKey:@"token"];
    NSLog(@"OOOOOOOO     %@    0000000", token);

    
    //  snap = [NSString stringWithFormat: @"%ld", (long)tempInt];
    
    
    NSDictionary *parameters = @{@"token": token,@"id":snapID};
    manager = [[AFHTTPSessionManager alloc]initWithSessionConfiguration:[NSURLSessionConfiguration defaultSessionConfiguration]];
    [manager setRequestSerializer:[AFHTTPRequestSerializer serializer]];
    [manager setResponseSerializer:[AFJSONResponseSerializer serializer]];
    
    [manager GET:@"http://www.tageninformatics.com/client/jwu/csis3070_assignment3/snap/retrieve/"
      parameters:parameters
        progress:nil
         success:^(NSURLSessionTask *task, id responseObject) {
             //  [arrSnaps removeObjectAtIndex:[indexPath row]];
   //          [self.view reloadData];
             
             NSDictionary *response = responseObject;
             // = [[NSMutableArray alloc]initWithArray:[response objectForKey:@"snaps"]];
             NSLog(@"success");
             
             NSLog(@"-----------%@-----------", response);
             _firstName.text = [[response objectForKey:@"snap"] objectForKey:@"firstname"];
           //  [self.firstName reloadData];
 _lastName.text = [[response objectForKey:@"snap"] objectForKey:@"lastname"];
             _messageSnap.text = [[response objectForKey:@"snap"] objectForKey:@"message"];
             
             
             
             
             NSString *strImage;
             strImage = [[response objectForKey:@"snap"] objectForKey:@"image"];
             if (strImage) {
                 NSData *imageData = [[NSData alloc] initWithBase64EncodedString:strImage options:0];
                 UIImage *imageObj = [UIImage imageWithData:imageData];
                 _imageViews.image = imageObj;
             }

            // _firstName= [response objectForKey:@"firstname"];
             //if this is sucessful show the image view
             //name of the person
             //message
             
         } failure:^(NSURLSessionTask *operation, NSError	 *error) {
             NSLog(@"Network Error: %@", error);
         }];
    
    self.timeSec = 10;
    
    self.timer = [NSTimer scheduledTimerWithTimeInterval: 1.0 target:self selector:@selector(timerEnded) userInfo:nil repeats:TRUE];
   
 
}

-(void) timerEnded{
    _timinglbl.text  = [NSString stringWithFormat:@"%d",self.timeSec];
    self.timeSec = self.timeSec - 1;
    
   // if ([_timinglbl  isEqual: @"0"]){
        
      //  [self performSegueWithIdentifier:@"seguetolistview" sender:self];
        
        
    //}
    if (self.timeSec ==0){
        [self performSegueWithIdentifier:@"seguetolistview" sender:self];
    }
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
