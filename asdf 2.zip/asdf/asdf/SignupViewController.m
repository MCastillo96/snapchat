
#import "SignupViewController.h"


@implementation SignupViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]
                                   initWithTarget:self
                                   action:@selector(dismissKeyboard)];
    
    [self.view addGestureRecognizer:tap];
    
}


-(void)dismissKeyboard {
    [self.txtFirstname resignFirstResponder];
    [self.txtLastname resignFirstResponder];
    [self.txtEmail resignFirstResponder];
    [self.txtPassword resignFirstResponder];
}

- (IBAction)didClickCreateAccount:(id)sender {
    if(![self.txtFirstname hasText] || ![self.txtLastname hasText] || ![self.txtEmail hasText] || ![self.txtPassword hasText])
    {
        UIAlertController * alert = [UIAlertController
                                     alertControllerWithTitle:@"Error"
                                     message:@"Empty Fields are not permitted"
                                     preferredStyle:UIAlertControllerStyleAlert];
        
        
        UIAlertAction* okButton = [UIAlertAction
                                   actionWithTitle:@"OK"
                                   style:UIAlertActionStyleDefault
                                   handler:nil];
        
        [alert addAction:okButton];
        
        [self presentViewController:alert animated:YES completion:nil];
        
    }
    else{

        
        NSDictionary *parameters = @{@"email": self.txtEmail.text, @"password":self.txtPassword.text,@"firstname":self.txtFirstname.text,@"lastname":self.txtLastname.text};
        
        AFHTTPSessionManager *manager = [[AFHTTPSessionManager alloc]initWithSessionConfiguration:[NSURLSessionConfiguration defaultSessionConfiguration]];
        
        [manager setRequestSerializer:[AFHTTPRequestSerializer serializer]];
        [manager setResponseSerializer:[AFJSONResponseSerializer serializer]];
        
        [manager POST:@"http://www.tageninformatics.com/client/jwu/csis3070_assignment3/user/register/" parameters:parameters progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
            
            NSDictionary * response = responseObject;
            if ([[response objectForKey:@"result"] isEqualToString:@"success"]) {

                
                [manager POST:@"http://www.tageninformatics.com/client/jwu/csis3070_assignment3/user/login/" parameters:parameters progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    
                    NSDictionary * response = responseObject;
                    if ([[response objectForKey:@"result"] isEqualToString:@"success"]) {
                        NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
                        [defaults setObject:[response objectForKey:@"token"] forKey:@"token"];
                        [self performSegueWithIdentifier:@"segueSignupToList" sender:self];
                        
                    } else {
                        UIAlertController * alert = [UIAlertController
                                                     alertControllerWithTitle:@"Error"
                                                     message:[response objectForKey:@"message"]
                                                     preferredStyle:UIAlertControllerStyleAlert];
                        
                        UIAlertAction* okButton = [UIAlertAction
                                                   actionWithTitle:@"OK"
                                                   style:UIAlertActionStyleDefault
                                                   handler:nil];
                        
                        [alert addAction:okButton];
                        
                        [self presentViewController:alert animated:YES completion:nil];
                        
                        
                        
                    }
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    NSLog(@"Network Error: %@", error);
                }];
            
            } else {
                UIAlertController * alert = [UIAlertController
                                             alertControllerWithTitle:@"Error"
                                             message:[response objectForKey:@"message"]
                                             preferredStyle:UIAlertControllerStyleAlert];
                
                UIAlertAction* okButton = [UIAlertAction
                                           actionWithTitle:@"OK"
                                           style:UIAlertActionStyleDefault
                                           handler:nil];
                
                [alert addAction:okButton];
                
                [self presentViewController:alert animated:YES completion:nil];
                
                
                
            }
        } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
            NSLog(@"Network Error: %@", error);
        }];
        

    
    
    
    
    
    
    }

}
@end
