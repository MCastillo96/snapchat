

#import "MessageListViewController.h"
@interface MessageListViewController ()

@property (strong, nonatomic) NSMutableArray *array;

@end

@implementation MessageListViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    [self.tblSnaps reloadData];

    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    token =[defaults objectForKey:@"token"];

    NSDictionary *parameters = @{@"token": token};
    manager = [[AFHTTPSessionManager alloc]initWithSessionConfiguration:[NSURLSessionConfiguration defaultSessionConfiguration]];
    [manager setRequestSerializer:[AFHTTPRequestSerializer serializer]];
    [manager setResponseSerializer:[AFJSONResponseSerializer serializer]];

    [manager POST:@"http://www.tageninformatics.com/client/jwu/csis3070_assignment3/snap/list/"
      parameters:parameters
        progress:nil
         success:^(NSURLSessionTask *task, id responseObject) {
             NSDictionary *response = responseObject;
             arrSnaps = [[NSMutableArray alloc]initWithArray:[response objectForKey:@"snaps"]];
             [self.tblSnaps reloadData];
         } failure:^(NSURLSessionTask *operation, NSError	 *error) {
             NSLog(@"Network Error: %@", error);
         }];
    [self viewWillAppear];
    
}

- (NSArray *)tableView:(UITableView *)tableView editActionsForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    UITableViewRowAction *deleteAction = [UITableViewRowAction rowActionWithStyle:UITableViewRowActionStyleDestructive title:@"Delete"  handler:^(UITableViewRowAction *action, NSIndexPath *indexPath){

        //get the ID from
        NSString *snap_id = [[arrSnaps objectAtIndex:[indexPath row]] objectForKey:@"id"];
        //network call to delete
        NSDictionary *parameters = @{@"token": token,@"id":snap_id};

        [manager GET:@"http://www.tageninformatics.com/client/jwu/csis3070_assignment3/snap/delete/"
           parameters:parameters
             progress:nil
              success:^(NSURLSessionTask *task, id responseObject) {
                  [arrSnaps removeObjectAtIndex:[indexPath row]];
                  [self.tblSnaps reloadData];
              } failure:^(NSURLSessionTask *operation, NSError	 *error) {
                  NSLog(@"Network Error: %@", error);
              }];
    }];
    return @[deleteAction];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString * identifier = @"cell";
    UITableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    
    if (!cell)
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];

    
    NSDictionary * person = [arrSnaps objectAtIndex: indexPath.row];
    
    
    NSString *name = [NSString stringWithFormat: @"%@ %@",[person objectForKey:@"firstname"],[person objectForKey:@"lastname"]];
    cell.textLabel.text = name;
    cell.backgroundColor = ([indexPath row]%2)?[UIColor lightGrayColor]:[UIColor whiteColor];

    return cell;
}

-(NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [arrSnaps count];
}

- (NSInteger) numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}


//The ViewWillAppear Method
- (void) viewWillAppear {
    
    UIBarButtonItem *addSnap = [[UIBarButtonItem alloc] initWithTitle:@"New Snap" style:UIBarButtonItemStylePlain target: self action:@selector(didClickNewSnap:)];
    self.navigationItem.rightBarButtonItem = addSnap;
    
}




//Creating number 5
-(IBAction) didClickNewSnap: (id) sender {
    
    UIAlertController* sourceSelection = [UIAlertController
                                        alertControllerWithTitle:@"New Snap Source"
                                        message:nil
                                        preferredStyle:UIAlertControllerStyleActionSheet];
    
    UIAlertAction*  takingPhotoBtn = [UIAlertAction actionWithTitle:@"Take Photo"
                                                               style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                                                                   self.source = UIImagePickerControllerSourceTypePhotoLibrary;
                                                                   //[self performSegueWithIdentifier:@"segueMessageNewViewController" sender: self];
                                                                   [self segues];
                                                                   
                                                               }];
    
    UIAlertAction* CameraRollBtn = [UIAlertAction actionWithTitle:@"Camera Roll"
                                                               style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                                                                   self.source = UIImagePickerControllerSourceTypePhotoLibrary;
                                                                   //[self performSegueWithIdentifier:@"segueMessageNewViewController" sender: self];
                                                                  [self segues];
                                                                   
                                                               }];
    
    UIAlertAction* cancelButton = [UIAlertAction
                                   actionWithTitle:@"Cancel"
                                   style:UIAlertActionStyleCancel
                                   handler:nil];
    
    
    
    [sourceSelection addAction:takingPhotoBtn];
    [sourceSelection addAction:CameraRollBtn];
    [sourceSelection addAction:cancelButton];
    [self presentViewController:sourceSelection animated:YES completion:NULL];
    //[self performSegueWithIdentifier:@"segueMessageNewViewController" sender: self];
    
   // [self segues];
   //
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    
    
  //  UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    
    snapID = [[arrSnaps objectAtIndex:[indexPath row]] objectForKey:@"id"];
    NSLog(@"_________________%@________________", snapID);
   // _snapID= [ intValue];;
    //NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    //snapID = [defaults objectForKey:@"id"];
    //snapID = id;
    NSLog(@"This is %@", snapID);
     [self segues2];
}

-(void)segues{
    [self performSegueWithIdentifier:@"segueMessageNewViewController" sender: self];
    
}
-(void)segues2{
    [self performSegueWithIdentifier:@"MessageView" sender: self];
    
}

-(void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    
    if ([segue.identifier isEqualToString:@"segueMessageNewViewController"]) {
        MessageListViewController * destinationVC = [segue destinationViewController];
        destinationVC.source = _source;
        
    }
    
    if ([[segue identifier] isEqualToString:@"MessageView"]) {
        //NSInteger response = (NSInteger) _snapID;
        //NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
       // [[NSUserDefaults standardUserDefaults] setObject:snapID forKey:@"snapID"];
        [[NSUserDefaults standardUserDefaults] setObject:snapID forKey:@"id"];
        [[NSUserDefaults standardUserDefaults] synchronize];
    //  [defaults setObject:[response objectForKey:snapID]];
       // [self performSegueWithIdentifier:@"MessageView" sender:self];

    }

    
    
}


@end
